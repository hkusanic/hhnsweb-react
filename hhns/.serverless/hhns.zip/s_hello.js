var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'anuragjais',
applicationName: 'service',
appUid: 'zKSZQB3HZGNDwR4Bpf',
tenantUid: '7v97VcQ3GGlQT2CZ2j',
deploymentUid: 'b50659fb-23e2-4f43-89e5-d68420f295b3',
serviceName: 'hhns',
stageName: 'dev',
pluginVersion: '2.0.0'})
const handlerWrapperArgs = { functionName: 'hhns-dev-hello', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
